package com.cirium.test;

import java.time.Instant;

public class Flight {
    /** The aerodrome the flight is arriving at. */
    private final String arrivalAerodrome;

    /** The date/time the flight is arriving. */
    private final Instant arrivalTime;

    /** The coordinate of the arrival aerodrome. */
    private final Coordinate arrivalCoordinate;

    /** The aerodrome the flight is departing from. */
    private final String departureAerodrome;

    /** The date/time the flight is departing. */
    private final Instant departureTime;

    /** The coordinate of the departure aerodrome. */
    private final Coordinate departureCoordinate;

    /**
     * Construct a flight.
     *
     * @param arrivalAerodrome The aerodrome the flight is arriving at.
     * @param arrivalTime The date/time the flight is arriving.
     * @param departureAerodrome The aerodrome the flight is departing from.
     * @param departureTime The date/time the flight is departing.
     * @param arrivalCoordinate The coordinate of the arrival aerodrome.
     * @param departureCoordinate The coordinate of the departure aerodrome.
     */
    public Flight(final String arrivalAerodrome, 
        final Instant arrivalTime, 
        final String departureAerodrome, 
        final Instant departureTime, 
        final Coordinate arrivalCoordinate, 
        final Coordinate departureCoordinate) {
        this.arrivalAerodrome = arrivalAerodrome;
        this.arrivalTime = arrivalTime;
        this.departureAerodrome = departureAerodrome;
        this.departureTime = departureTime;
        this.arrivalCoordinate = arrivalCoordinate;
        this.departureCoordinate = departureCoordinate;
    }

    /**
     * Gets the aerodrome the flight is arriving at.
     *
     * @return the arrival aerodrome.
     */
    public String getArrivalAerodrome() {
        return arrivalAerodrome;
    }

    /**
     * Gets the date/time the flight is arriving.
     *
     * @return the arrival time.
     */
    public Instant getArrivalTime() {
        return arrivalTime;
    }

    /**
     * Gets the aerodrome the flight is departing from.
     *
     * @return the departure aerodrome.
     */
    public String getDepartureAerodrome() {
        return departureAerodrome;
    }

    /**
     * Gets the date/time the flight is departing.
     *
     * @return the departure time.
     */
    public Instant getDepartureTime() {
        return departureTime;
    }

    /**
     * Gets the coordinate of the arrival aerodrome.
     *
     * @return the arrival coordinate.
     */
    public Coordinate getArrivalCoordinate() {
        return arrivalCoordinate;
    }

    /**
     * Gets the coordinate of the departure aerodrome.
     *
     * @return the departure coordinate.
     */
    public Coordinate getDepartureCoordinate() {
        return departureCoordinate;
    }

    public Coordinate getLocation(final Instant now) {

        // If the flight has not yet departed, it is at the departure aerodrome.
        if (now.isBefore(departureTime)) {
            return departureCoordinate;
        }

        // If the flight has arrived, it is at the arrival aerodrome.
        if (now.isAfter(arrivalTime)) {
            return arrivalCoordinate;
        }

        // Calculate total flight duration in seconds.
        final long totalFlightDuration = arrivalTime.getEpochSecond() - departureTime.getEpochSecond();

        // Avoid division by zero if departure and arrival times are the same.
        if (totalFlightDuration == 0) {
            return departureCoordinate;
        }

        // 1. Calculate total distance in X and Y directions.
        final double totalDistanceX = arrivalCoordinate.getX() - departureCoordinate.getX();
        final double totalDistanceY = arrivalCoordinate.getY() - departureCoordinate.getY();

        // 2. Calculate speed in X and Y directions (distance per second).
        final double speedX = totalDistanceX / totalFlightDuration;
        final double speedY = totalDistanceY / totalFlightDuration;

        // 3. Calculate time elapsed since departure in seconds.
        final long timeElapsed = now.getEpochSecond() - departureTime.getEpochSecond();

        // 4. Calculate current position using the formula: position = start + (speed * time).
        final double currentX = departureCoordinate.getX() + (speedX * timeElapsed);
        final double currentY = departureCoordinate.getY() + (speedY * timeElapsed);

        return new Coordinate(currentX, currentY);
    }
}
