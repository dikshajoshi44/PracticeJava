package com.wise.practice;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.Queue;

/**
 * A single-file implementation of the Circuit Breaker pattern for interview preparation.
 * This version is simplified for clarity and to be coded within an hour.
 */
public class ApiService {

  // --- Custom Exceptions to Simulate HTTP Errors ---
  private static class HttpClientErrorException extends RuntimeException {
    public HttpClientErrorException(String message) { super(message); }
  }

  private static class HttpServerErrorException extends RuntimeException {
    public HttpServerErrorException(String message) { super(message); }
  }

  // Enum to represent the state of the circuit breaker.
  public enum State {
    CLOSED, OPEN, HALF_OPEN
  }

  private final CircuitBreakerService circuitBreaker;
  private final UnstableApi api;

  public ApiService() {
    this.api = new UnstableApi();

    // Configuration for the single overburdened API:
    int failureThreshold = 4; // Y: Trip if error count >= 4
    Duration failureTimeWindow = Duration.ofMinutes(1); // X: in the last 1 minute
    Duration coolOffPeriod = Duration.ofSeconds(15); // Z: Cool-off for 15 seconds (shortened for demo)
    int halfOpenSuccessThreshold = 2;

    this.circuitBreaker = new CircuitBreakerService(
      failureThreshold, failureTimeWindow, coolOffPeriod, halfOpenSuccessThreshold
    );
  }

  /**
   * Executes a request, wrapped by a circuit breaker. This is the public-facing method.
   */
  public String callApi() {
    CircuitBreakerService cb = this.circuitBreaker;

    if (cb.getState() == State.OPEN) {
      if (cb.isReadyForHalfOpen()) {
        cb.moveToHalfOpen();
      } else {
        System.out.println("-> Circuit is OPEN. Request rejected immediately.");
        return "Request Rejected: Service Unavailable";
      }
    }

    // In CLOSED or HALF_OPEN state, attempt to execute the operation.
    try {
      String result = api.call();
      cb.recordSuccess();
      return result;
    } catch (HttpServerErrorException e) {
      // This is a server error (5xx), so we record it as a failure.
      System.out.println("Caught a server error. Recording as failure.");
      cb.recordFailure();
      return "Request Failed (Server Error): " + e.getMessage();
    } catch (HttpClientErrorException e) {
      // This is a client error (4xx). We do NOT record this as a system failure.
      // The circuit breaker should ignore it.
      System.out.println("Caught a client error. Ignoring for circuit breaker.");
      return "Request Failed (Client Error): " + e.getMessage();
    }
  }

  /**
   * Inner class for the core circuit breaker logic. Encapsulating this makes the main class cleaner.
   */
  private static class CircuitBreakerService {
    // The current state of the circuit breaker.
    private State state;
    // The number of failures in a time window required to trip the circuit.
    private final int failureThreshold;
    // The time window for tracking failures.
    private final Duration failureTimeWindow;
    // The duration the circuit stays open before moving to half-open.
    private final Duration openStateTimeout;
    // The number of successful trials in half-open required to close the circuit.
    private final int halfOpenSuccessThreshold;

    // A queue to store the timestamps of recent failures.
    private final Queue<LocalDateTime> failureTimestamps = new LinkedList<>();
    private int successCount;
    private LocalDateTime lastStateChangeTime;

    public CircuitBreakerService(int failureThreshold, Duration failureTimeWindow,
                                 Duration openStateTimeout, int halfOpenSuccessThreshold) {
      this.failureThreshold = failureThreshold;
      this.failureTimeWindow = failureTimeWindow;
      this.openStateTimeout = openStateTimeout;
      this.halfOpenSuccessThreshold = halfOpenSuccessThreshold;
      this.state = State.CLOSED; // Start in a healthy state.
    }

    public State getState() {
      return state;
    }

    // Using 'synchronized' to ensure thread-safety when updating state.
    public synchronized void recordFailure() {
      if (state == State.CLOSED) {
        LocalDateTime now = LocalDateTime.now();
        // Remove old failure timestamps that are outside the time window.
        failureTimestamps.removeIf(timestamp -> Duration.between(timestamp, now).compareTo(failureTimeWindow) > 0);

        // Record the new failure.
        failureTimestamps.add(now);

        System.out.println("  - Failure recorded. Failures in last " + failureTimeWindow.getSeconds() + "s: " + failureTimestamps.size());
        if (failureTimestamps.size() >= failureThreshold) {
          moveToOpen();
        }
      } else if (state == State.HALF_OPEN) {
        // A single failure in half-open should immediately re-open the circuit.
        moveToOpen();
      }
    }

    public synchronized void recordSuccess() {
      if (state == State.HALF_OPEN) {
        successCount++;
        System.out.println("  - Success in HALF_OPEN. Count: " + successCount);
        if (successCount >= halfOpenSuccessThreshold) {
          moveToClosed();
        }
      } else if (state == State.CLOSED) {
        // A success in the closed state doesn't need to do anything in a time-window model.
        // Old failures will naturally expire from the queue over time.
      }
    }

    public boolean isReadyForHalfOpen() {
      return Duration.between(lastStateChangeTime, LocalDateTime.now()).compareTo(openStateTimeout) > 0;
    }

    public void moveToHalfOpen() {
      System.out.println("... Circuit moved to HALF_OPEN state ...");
      this.state = State.HALF_OPEN;
      this.successCount = 0; // Reset success counter for the new trial period.
    }

    private void moveToClosed() {
      System.out.println("### Circuit moved to CLOSED state ###");
      this.state = State.CLOSED;
      // Clear failure history on successful recovery.
      failureTimestamps.clear();
      this.successCount = 0;
    }

    private void moveToOpen() {
      System.out.println("!!! Circuit moved to OPEN state !!!");
      this.state = State.OPEN;
      this.lastStateChangeTime = LocalDateTime.now();
      // Clear the failure history when the circuit opens.
      failureTimestamps.clear();
    }
  }

  /**
   * A dummy backend service simulator with predictable failure scenarios.
   */
  /** A dummy API that simulates being unstable. */
  private static class UnstableApi {
    private int callCount = 0;

    public String call() {
      System.out.println("Attempting to call the overburdened API...");
      callCount++;

      // On the first call, simulate a client error (e.g., 400 Bad Request).
      if (callCount == 1) {
        throw new HttpClientErrorException("Bad Request");
      }

      // For the next 4 calls, simulate a server error (e.g., 503 Service Unavailable).
      if (callCount > 1 && callCount <= 5) {
        throw new HttpServerErrorException("Service Unavailable");
      }

      // After that, the API recovers.
      return "Success from API";
    }
  }

  public static void main(String[] args) throws InterruptedException {
    ApiService service = new ApiService();

    System.out.println("--- Step 1: Simulate a mix of client and server errors ---");
    // The circuit should ignore the first (4xx) error and trip after four 5xx errors.
    for (int i = 0; i < 5; i++) {
      System.out.println("Request " + (i + 1) + ": " + service.callApi());
    }

    System.out.println("\n--- Step 2: Circuit is now OPEN. Requests should fail fast. ---");
    System.out.println("Request 6: " + service.callApi());

    System.out.println("\n--- Step 3: Waiting for the cool-off period (15 seconds) to pass... ---");
    Thread.sleep(15000);

    System.out.println("\n--- Step 4: Circuit is now HALF_OPEN. Sending trial requests. ---");
    // The API has now recovered (it only failed the first 4 times).
    // These trial requests should succeed.
    System.out.println("Trial Request 1: " + service.callApi());
    System.out.println("Trial Request 2: " + service.callApi());

    System.out.println("\n--- Step 5: Circuit is now CLOSED again. Normal operation resumes. ---");
    System.out.println("Final Request: " + service.callApi());
  }
}
