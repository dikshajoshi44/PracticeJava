package com.wise.practice;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.Queue;

public class ApiServiceFinal {

  private enum State {
    OPEN,
    CLOSED,
    HALF_OPEN
  }

  private static class HttpClientErrorException extends RuntimeException {
    public HttpClientErrorException(String message) { super(message); }
  }

  private static class HttpServerErrorException extends RuntimeException {
    public HttpServerErrorException(String message) { super(message); }
  }

  private CircuitBreakerService circuitBreakerService;
  private UnstableApi unstableApi;

  public ApiServiceFinal() {
    this.circuitBreakerService = new CircuitBreakerService(
      State.CLOSED,
      5,
      Duration.ofMinutes(1),
      Duration.ofSeconds(15),
      2
    );
    this.unstableApi = new UnstableApi();
  }

    public String callApi() {
      CircuitBreakerService circuitBreakerService = this.circuitBreakerService;

      // In CLOSED or HALF_OPEN state, attempt to execute the operation.
      try {
        String result = unstableApi.call();
        circuitBreakerService.recordSuccess();
        return result;
      } catch (HttpServerErrorException e) {
        // This is a server error (5xx), so we record it as a failure.
        System.out.println("Caught a server error. Recording as failure.");
        circuitBreakerService.recordFailure();
        return "Request Failed (Server Error): " + e.getMessage();
      } catch (HttpClientErrorException e) {
        // This is a client error (4xx). We do NOT record this as a system failure.
        // The circuit breaker should ignore it.
        System.out.println("Caught a client error. Ignoring for circuit breaker.");
        return "Request Failed (Client Error): " + e.getMessage();
      }
    }


  private static class UnstableApi {

    private int callCount = 0;

    public String call() {
      System.out.println("Attempting to call the overburdened API...");
      callCount++;

      // On the first call, simulate a client error (e.g., 400 Bad Request).
      if (callCount == 1) {
        throw new HttpClientErrorException("Bad Request");
      }

      // For the next 4 calls, simulate a server error (e.g., 503 Service Unavailable).
      if (callCount > 1 && callCount <= 5) {
        throw new HttpServerErrorException("Service Unavailable");
      }

      // After that, the API recovers.
      return "Success from API";
    }
  }

  private static class CircuitBreakerService {
    private State state;
    private int failureThreshold;
    private Duration failureTimeWindow;
    private Duration coolOffPeriod;
    private int halfOpenSuccessThreshold;

    private final Queue<LocalDateTime> failureTimestamps = new LinkedList<>();
    private int successCount;
    private LocalDateTime lastStateChangeTime;

    public CircuitBreakerService(State state, int failureThreshold,
                                 Duration failureTimeWindow, Duration coolOffPeriod,
                                 int halfOpenSuccessThreshold) {
      this.state = state;
      this.failureThreshold = failureThreshold;
      this.failureTimeWindow = failureTimeWindow;
      this.coolOffPeriod = coolOffPeriod;
      this.halfOpenSuccessThreshold = halfOpenSuccessThreshold;

    }

    public State getState() {
      return state;
    }

    public synchronized void recordFailure() {
      if(state == State.CLOSED) {
        LocalDateTime now = LocalDateTime.now();
        failureTimestamps.removeIf(timestamp -> Duration.between(timestamp, now).compareTo(failureTimeWindow) > 0);
        failureTimestamps.add(now);

        if(failureTimestamps.size() >= failureThreshold) {
          moveToOpen();
        }

      }else if(state == State.HALF_OPEN) {
        moveToOpen();
      }
    }

    public synchronized void recordSuccess() {
      if(state == State.HALF_OPEN) {
        successCount++;
        if(successCount >= halfOpenSuccessThreshold) {
          moveToClosed();
        }
      }
    }

    public void moveToClosed() {
      state = State.CLOSED;
      failureTimestamps.clear();
      successCount = 0;
      System.out.println("... Circuit moved to CLOSED state ...");
    }

    public void moveToOpen() {
      state = State.OPEN;
      lastStateChangeTime = LocalDateTime.now();
      failureTimestamps.clear();
      System.out.println("... Circuit moved to OPEN state ...");
    }


  }


}
