package com.wise.practice;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import static java.time.LocalDateTime.now;

public class CircuitBreaker2 {

  public enum State {
    CLOSED,
    OPEN,
    HALF_OPEN
  }

  private final Map<String, BackendServiceCircuitBreaker> circuitBreakers = new HashMap<>();

  public CircuitBreaker2() {
    circuitBreakers.put("Service1", new BackendServiceCircuitBreaker(5, Duration.ofSeconds(5),
      Duration.ofSeconds(30), 2));
    circuitBreakers.put("Service2", new BackendServiceCircuitBreaker(8, Duration.ofSeconds(10),
      Duration.ofSeconds(35), 3));
    circuitBreakers.put("Service3", new BackendServiceCircuitBreaker(10, Duration.ofSeconds(15),
      Duration.ofSeconds(40), 4));
  }


  private static class BackendServiceCircuitBreaker {
    private State state;
    private final int failureThreshold;
    private final Duration failureTimeWindow;
    private final Duration openStateTimeout;
    private final int halfOpenSuccessThreshold;

    private final Queue<LocalDateTime> recentFailureTimestamps = new LinkedList<>();
    private int successCount;
    private LocalDateTime lastStateChangeTime;

    public BackendServiceCircuitBreaker(int failureThreshold, Duration failureTimeWindow,
                                        Duration openStateTimeout, int halfOpenSuccessThreshold) {
      this.failureThreshold = failureThreshold;
      this.failureTimeWindow = failureTimeWindow;
      this.openStateTimeout = openStateTimeout;
      this.halfOpenSuccessThreshold = halfOpenSuccessThreshold;
      this.state = State.CLOSED;
    }

    public State getState() {
      return state;
    }

    public void recordFailure() {
        if(state == State.CLOSED) {
          recentFailureTimestamps.removeIf(timestamp -> Duration.between(timestamp, now()).compareTo(failureTimeWindow) > 0);
          recentFailureTimestamps.add(now());

          if(recentFailureTimestamps.size() >= failureThreshold) {
            moveToOpen();
          }

        }else if(state == State.HALF_OPEN) {
          moveToOpen();
        }
    }

    public void recordSuccess() {
      if(state == State.HALF_OPEN) {
        successCount++;
        if(successCount >= halfOpenSuccessThreshold) {
          moveToClose();
        }
      }
    }

    public void moveToOpen() {
      state = State.OPEN;
      lastStateChangeTime = now();
      recentFailureTimestamps.clear();
    }

    public void moveToClose() {
      state = State.CLOSED;
      recentFailureTimestamps.clear();
      successCount = 0;
    }

    public void moveToHalfOpen() {
      state = State.HALF_OPEN;
      successCount = 0;
    }


  }
}
