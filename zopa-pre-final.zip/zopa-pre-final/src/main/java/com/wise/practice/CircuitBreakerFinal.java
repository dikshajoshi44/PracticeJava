//package com.wise.practice;
//
//import java.time.Duration;
//import java.time.LocalDateTime;
//import java.util.LinkedList;
//import java.util.Map;
//import java.util.Queue;
//import java.util.concurrent.ConcurrentHashMap;
//import java.util.function.Supplier;
//
///**
// * A single-file implementation of the Circuit Breaker pattern for interview preparation.
// * This version is simplified for clarity and to be coded within an hour.
// */
//public class CircuitBreakerFinal {
//
//  // Enum to represent the state of the circuit breaker. Clear and type-safe.
//  public enum State {
//    CLOSED,   // Allows operations to execute
//    OPEN,     // Trips and rejects operations immediately
//    HALF_OPEN // Allows a limited number of trial operations
//  }
//
//  private final Map<String, BackendServiceCircuitBreaker> circuitBreakers = new ConcurrentHashMap<>();
//  private final BackendService backendService;
//
//  public CircuitBreakerFinal() {
//    this.backendService = new BackendService();
//    // Initialize circuit breakers for each backend service with specific thresholds.
//    // Using a ConcurrentHashMap to manage breakers for different services is a clean way to scale.
//    // --- Per-Service Configuration ---
//    // Each service gets its own configuration, as they might have different reliability.
//
//    // --- Per-Service Configuration with Time Windows ---
//
//    // Brittle Service: Trips if 3 failures occur within a 30-second window.
//    circuitBreakers.put("brittle-service-1", new BackendServiceCircuitBreaker(3, Duration.ofSeconds(30), Duration.ofSeconds(20), 2));
//
//    // Standard Service: Trips if 5 failures occur within a 1-minute window.
//    circuitBreakers.put("standard-service-2", new BackendServiceCircuitBreaker(5, Duration.ofMinutes(1), Duration.ofSeconds(10), 2));
//
//    // Reliable Service: Trips if 10 failures occur within a 1-minute window.
//    circuitBreakers.put("reliable-service-3", new BackendServiceCircuitBreaker(10, Duration.ofMinutes(1), Duration.ofSeconds(10), 3));
//  }
//
//  /**
//   * Executes a request, wrapped by a circuit breaker. This is the public-facing method.
//   */
//  public String execute(String serviceId) {
//    BackendServiceCircuitBreaker cb = circuitBreakers.get(serviceId);
//    if (cb == null) {
//      throw new IllegalArgumentException("Unknown service ID: " + serviceId);
//    }
//
//    if (cb.getState() == State.OPEN) {
//      if (cb.isReadyForHalfOpen()) {
//        cb.moveToHalfOpen();
//      } else {
//        System.out.println("-> Circuit is OPEN for '" + serviceId + "'. Request rejected immediately.");
//        return "Request Rejected: Service Unavailable";
//      }
//    }
//
//    // In CLOSED or HALF_OPEN state, attempt to execute the operation.
//    try {
//      String result = backendService.call(serviceId);
//      cb.recordSuccess(); // On success, notify the circuit breaker.
//      return result;
//    } catch (Exception e) {
//      cb.recordFailure(); // On failure, notify the circuit breaker.
//      return "Request Failed: " + e.getMessage();
//    }
//  }
//
//  /**
//   * Inner class for the core circuit breaker logic. Encapsulating this makes the main class cleaner.
//   */
//  private static class BackendServiceCircuitBreaker {
//    // The current state of the circuit breaker.
//    private State state;
//    // The number of failures in a time window required to trip the circuit.
//    private final int failureThreshold;
//    // The time window for tracking failures.
//    private final Duration failureTimeWindow;
//    // The duration the circuit stays open before moving to half-open.
//    private final Duration openStateTimeout;
//    // The number of successful trials in half-open required to close the circuit.
//    private final int halfOpenSuccessThreshold;
//
//    // A queue to store the timestamps of recent failures.
//    private final Queue<LocalDateTime> failureTimestamps = new LinkedList<>();
//    private int successCount;
//    private LocalDateTime lastStateChangeTime;
//
//    public BackendServiceCircuitBreaker(int failureThreshold, Duration failureTimeWindow,
//                                        Duration openStateTimeout, int halfOpenSuccessThreshold) {
//      this.failureThreshold = failureThreshold;
//      this.failureTimeWindow = failureTimeWindow;
//      this.openStateTimeout = openStateTimeout;
//      this.halfOpenSuccessThreshold = halfOpenSuccessThreshold;
//      this.state = State.CLOSED; // Start in a healthy state.
//    }
//
//    public State getState() {
//      return state;
//    }
//
//    // Using 'synchronized' to ensure thread-safety when updating state.
//    public synchronized void recordFailure() {
//      if (state == State.CLOSED) {
//        LocalDateTime now = LocalDateTime.now();
//        // Remove old failure timestamps that are outside the time window.
//        failureTimestamps.removeIf(timestamp -> Duration.between(timestamp, now).compareTo(failureTimeWindow) > 0);
//
//        // Record the new failure.
//        failureTimestamps.add(now);
//
//        System.out.println("  - Failure recorded. Failures in last " + failureTimeWindow.getSeconds() + "s: " + failureTimestamps.size());
//        if (failureTimestamps.size() >= failureThreshold) {
//          moveToOpen();
//        }
//      } else if (state == State.HALF_OPEN) {
//        // A single failure in half-open should immediately re-open the circuit.
//        moveToOpen();
//      }
//    }
//
//    public synchronized void recordSuccess() {
//      if (state == State.HALF_OPEN) {
//        successCount++;
//        System.out.println("  - Success in HALF_OPEN. Count: " + successCount);
//        if (successCount >= halfOpenSuccessThreshold) {
//          moveToClosed();
//        }
//      } else if (state == State.CLOSED) {
//        // A success in the closed state doesn't need to do anything in a time-window model.
//        // Old failures will naturally expire from the queue over time.
//      }
//    }
//
//    public boolean isReadyForHalfOpen() {
//      return Duration.between(lastStateChangeTime, LocalDateTime.now()).compareTo(openStateTimeout) > 0;
//    }
//
//    public void moveToHalfOpen() {
//      System.out.println("... Circuit moved to HALF_OPEN state ...");
//      this.state = State.HALF_OPEN;
//      this.successCount = 0; // Reset success counter for the new trial period.
//    }
//
//    private void moveToClosed() {
//      System.out.println("### Circuit moved to CLOSED state ###");
//      this.state = State.CLOSED;
//      // Clear failure history on successful recovery.
//      failureTimestamps.clear();
//      this.successCount = 0;
//    }
//
//    private void moveToOpen() {
//      System.out.println("!!! Circuit moved to OPEN state !!!");
//      this.state = State.OPEN;
//      this.lastStateChangeTime = LocalDateTime.now();
//      // Clear the failure history when the circuit opens.
//      failureTimestamps.clear();
//    }
//  }
//
//  /**
//   * A dummy backend service simulator with predictable failure scenarios.
//   */
//  private static class BackendService {
//    private final Map<String, Integer> callCounts = new ConcurrentHashMap<>();
//
//    public BackendService() {
//      callCounts.put("brittle-service-1", 0);
//      callCounts.put("standard-service-2", 0);
//      callCounts.put("reliable-service-3", 0);
//    }
//
//    public String call(String serviceId) {
//      System.out.println("Attempting to call '" + serviceId + "'...");
//      int count = callCounts.compute(serviceId, (k, v) -> (v == null) ? 1 : v + 1);
//
//      // Brittle service: Fails for the first 3 calls to ensure it trips.
//      if ("brittle-service-1".equals(serviceId) && count <= 3) {
//        throw new RuntimeException("Brittle service failed as expected.");
//      }
//
//      // Standard service: Fails every 4th time.
//      if ("standard-service-2".equals(serviceId) && count % 4 == 0) {
//        throw new RuntimeException("Standard service failed periodically.");
//      }
//
//      // Reliable service always succeeds.
//      if ("reliable-service-3".equals(serviceId)) {
//        return "Success from reliable-service-3";
//      }
//
//      return "Success from " + serviceId;
//    }
//
//    public java.util.Set<String> getAvailableServices() {
//      return callCounts.keySet();
//    }
//  }
//
//  public static void main(String[] args) throws InterruptedException {
//    CircuitBreaker service = new CircuitBreaker();
//
//    System.out.println("--- Scenario 1: Hammer the brittle service to trip its circuit ---");
//    // This service is configured to trip after 3 failures in 30s. The first 3 calls will fail.
//    for (int i = 0; i < 3; i++) {
//      System.out.println("Request " + (i + 1) + ": " + service.execute("brittle-service-1"));
//      Thread.sleep(1000); // Space out failures slightly
//    }
//    // This 4th call should be rejected as the circuit should now be open.
//    System.out.println("Request 4: " + service.execute("brittle-service-1"));
//
//    System.out.println("\n--- Brittle service circuit is OPEN. Other services should be unaffected. ---");
//    System.out.println("Request to brittle-service-1: " + service.execute("brittle-service-1"));
//    System.out.println("Request to standard-service-2: " + service.execute("standard-service-2"));
//    System.out.println("Request to reliable-service-3: " + service.execute("reliable-service-3"));
//
//    System.out.println("\n--- Waiting for brittle service's OPEN state timeout (20 seconds) ---");
//    Thread.sleep(20000);
//
//    System.out.println("\n--- Brittle service is now HALF_OPEN. Sending trial requests. ---");
//    // These next two requests should succeed and close the circuit.
//    System.out.println("Trial Request 1: " + service.execute("brittle-service-1"));
//    System.out.println("Trial Request 2: " + service.execute("brittle-service-1"));
//
//    System.out.println("\n--- Brittle service circuit should be CLOSED again. ---");
//    System.out.println("Final Request to brittle-service-1: " + service.execute("brittle-service-1"));
//  }
//}
