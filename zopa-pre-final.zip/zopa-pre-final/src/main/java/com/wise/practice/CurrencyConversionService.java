package com.wise.practice;

import com.wise.practice.exceptions.InvalidCurrencyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A thread-safe service for converting currencies.
 */
public class CurrencyConversionService {

    private static final Logger logger = LoggerFactory.getLogger(CurrencyConversionService.class);
    private static final int SCALE = 4; // Number of decimal places for rounding

    // Using ConcurrentHashMap for thread-safe access to exchange rates.
    // The key is a string like "EUR-GBP", and the value is the exchange rate.
    private final Map<String, BigDecimal> exchangeRates = new ConcurrentHashMap<>();

    public CurrencyConversionService() {
        // Initialize with some default exchange rates
        updateExchangeRate("EUR", "GBP", new BigDecimal("0.85"));
        updateExchangeRate("GBP", "EUR", new BigDecimal("1.18"));
        updateExchangeRate("EUR", "USD", new BigDecimal("1.07"));
        updateExchangeRate("USD", "EUR", new BigDecimal("0.93"));
    }

    /**
     * Converts an amount from a source currency to a target currency.
     *
     * @param fromCurrency The source currency code (e.g., "EUR").
     * @param toCurrency   The target currency code (e.g., "GBP").
     * @param amount       The amount to convert.
     * @return The converted amount.
     * @throws InvalidCurrencyException if the exchange rate is not available.
     */
    public BigDecimal convert(String fromCurrency, String toCurrency, BigDecimal amount) {
        if (fromCurrency == null || toCurrency == null || amount == null) {
            throw new IllegalArgumentException("Currency codes and amount must not be null.");
        }

        if (amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Amount must be non-negative.");
        }

        logger.info("Attempting to convert {} {} to {}", amount, fromCurrency, toCurrency);

        if (fromCurrency.equals(toCurrency)) {
            logger.info("Source and target currencies are the same. No conversion needed.");
            return amount;
        }

        String rateKey = fromCurrency + "-" + toCurrency;
        BigDecimal rate = exchangeRates.get(rateKey);

        if (rate == null) {
            logger.error("Exchange rate not found for {} to {}", fromCurrency, toCurrency);
            throw new InvalidCurrencyException("Exchange rate not available for " + fromCurrency + " to " + toCurrency);
        }

        BigDecimal convertedAmount = amount.multiply(rate).setScale(SCALE, RoundingMode.HALF_UP);
        logger.info("Successfully converted {} {} to {} {}. Rate: {}", amount, fromCurrency, convertedAmount, toCurrency, rate);

        return convertedAmount;
    }

    /**
     * Updates the exchange rate for a given currency pair.
     * This method is thread-safe because it operates on a ConcurrentHashMap.
     *
     * @param fromCurrency The source currency.
     * @param toCurrency   The target currency.
     * @param rate         The new exchange rate.
     */
    public void updateExchangeRate(String fromCurrency, String toCurrency, BigDecimal rate) {
        if (fromCurrency == null || toCurrency == null || rate == null) {
            throw new IllegalArgumentException("Currency codes and rate must not be null.");
        }
        String rateKey = fromCurrency + "-" + toCurrency;
        exchangeRates.put(rateKey, rate);
        logger.info("Updated exchange rate for {} to {}: {}", fromCurrency, toCurrency, rate);
    }
}
