package com.wise.practice;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * A single-file, production-style currency converter solution.
 * This class demonstrates OOP principles and thread-safety for a currency conversion service,
 * suitable for a coding assessment like HackerRank.
 */
public class CurrencyConverter {

    /**
     * Custom exception for handling cases where a currency or its exchange rate is not found.
     */
    public static class InvalidCurrencyException extends RuntimeException {
        public InvalidCurrencyException(String message) {
            super(message);
        }
    }

    /**
     * A thread-safe service for converting currencies.
     * It encapsulates exchange rate management and conversion logic.
     */
    public static class CurrencyConversionService {

        private static final int SCALE = 4; // Precision for monetary calculations
        private static final RoundingMode ROUNDING_MODE = RoundingMode.HALF_UP;

        // Using ConcurrentHashMap for thread-safe, non-blocking access to exchange rates.
        private final Map<String, BigDecimal> exchangeRates = new ConcurrentHashMap<>();

        public CurrencyConversionService() {
            // Initialize with some default exchange rates
            updateExchangeRate("EUR", "GBP", new BigDecimal("0.85"));
            updateExchangeRate("GBP", "EUR", new BigDecimal("1.18"));
            updateExchangeRate("EUR", "USD", new BigDecimal("1.07"));
            updateExchangeRate("USD", "EUR", new BigDecimal("0.93"));
        }

        /**
         * Converts an amount from a source currency to a target currency.
         *
         * @param fromCurrency The source currency code (e.g., "EUR").
         * @param toCurrency   The target currency code (e.g., "GBP").
         * @param amount       The amount to convert.
         * @return The converted amount.
         * @throws InvalidCurrencyException if the exchange rate is not available.
         * @throws IllegalArgumentException if inputs are invalid.
         */
        public BigDecimal convert(String fromCurrency, String toCurrency, BigDecimal amount) {
            if (fromCurrency == null || toCurrency == null || amount == null) {
                throw new IllegalArgumentException("Currency codes and amount must not be null.");
            }
            if (amount.compareTo(BigDecimal.ZERO) < 0) {
                throw new IllegalArgumentException("Amount must be non-negative.");
            }

            System.out.printf("Attempting to convert %s %s to %s...%n", amount, fromCurrency, toCurrency);

            if (fromCurrency.equals(toCurrency)) {
                return amount;
            }

            String rateKey = fromCurrency + "-" + toCurrency;
            BigDecimal rate = exchangeRates.get(rateKey);

            if (rate == null) {
                throw new InvalidCurrencyException("Exchange rate not available for " + fromCurrency + " to " + toCurrency);
            }

            BigDecimal convertedAmount = amount.multiply(rate).setScale(SCALE, ROUNDING_MODE);
            System.out.printf("Successfully converted to %s %s.%n", convertedAmount, toCurrency);
            return convertedAmount;
        }

        /**
         * Updates or adds an exchange rate. This method is thread-safe.
         */
        public void updateExchangeRate(String fromCurrency, String toCurrency, BigDecimal rate) {
            if (fromCurrency == null || toCurrency == null || rate == null) {
                throw new IllegalArgumentException("Currency codes and rate must not be null.");
            }
            String rateKey = fromCurrency + "-" + toCurrency;
            exchangeRates.put(rateKey, rate);
        }
    }

    /**
     * Main method to demonstrate the CurrencyConversionService functionality.
     */
    public static void main(String[] args) {
        CurrencyConversionService service = new CurrencyConversionService();

        System.out.println("--- Basic Conversion Test ---");
        service.convert("EUR", "GBP", new BigDecimal("100"));

        System.out.println("\n--- Invalid Argument Test ---");
        try {
            service.convert("EUR", "GBP", new BigDecimal("-50"));
        } catch (IllegalArgumentException e) {
            System.out.println("Caught expected exception: " + e.getMessage());
        }

        System.out.println("\n--- Missing Rate Test ---");
        try {
            service.convert("EUR", "JPY", new BigDecimal("100"));
        } catch (InvalidCurrencyException e) {
            System.out.println("Caught expected exception: " + e.getMessage());
        }

        System.out.println("\n--- Thread-Safety Test ---");
        runThreadSafetyTest(service);
    }

    private static void runThreadSafetyTest(CurrencyConversionService service) {
        int numThreads = 10;
        ExecutorService executor = Executors.newFixedThreadPool(numThreads);
        CountDownLatch latch = new CountDownLatch(numThreads);

        // Initial rate
        service.updateExchangeRate("USD", "CAD", new BigDecimal("1.25"));

        for (int i = 0; i < numThreads; i++) {
            final int threadNum = i;
            executor.submit(() -> {
                try {
                    if (threadNum % 2 == 0) {
                        // Reader thread
                        service.convert("USD", "CAD", new BigDecimal("10"));
                    } else {
                        // Writer thread
                        BigDecimal newRate = new BigDecimal("1.25").add(new BigDecimal(threadNum).divide(new BigDecimal("100")));
                        service.updateExchangeRate("USD", "CAD", newRate);
                        System.out.println("Thread " + threadNum + " updated rate to " + newRate);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    latch.countDown();
                }
            });
        }

        try {
            latch.await(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            e.printStackTrace();
        }

        executor.shutdown();
        System.out.println("\nThread-safety test finished. Final conversion:");
        service.convert("USD", "CAD", new BigDecimal("10"));
    }
}
