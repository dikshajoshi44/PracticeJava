package com.wise.practice;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.Queue;

import static java.time.LocalTime.now;

public class WiseInterviewService {

  private BackendServer backendServer;
  private CircuitBreakerServer circuitBreakerServer;

  public enum State {
    OPEN,
    CLOSED,
    HALF_OPEN
  }

  public WiseInterviewService(BackendServer backendServer,
                              CircuitBreakerServer circuitBreakerServer) {
    this.backendServer = backendServer;
    this.circuitBreakerServer = circuitBreakerServer;

  }


  public static class BackendServer {

  }

  public static class CircuitBreakerServer {
    private State state;
    private int failureThreshold;
    private Duration failureTimeWindow;
    private Duration coolOffPeriodOfHalfOpen;
    private int successThresholdForHalfOpen;

    private Queue<LocalDateTime> failureTimestamps = new LinkedList<>();
    private int successCount;
    private LocalDateTime lastOpenUpdatedAt;

    public CircuitBreakerServer(State state,
                                int failureThreshold,
                                Duration failureTimeWindow,
                                Duration coolOffPeriodOfHalfOpen,
                                int successThresholdForHalfOpen) {

      this.state = state;
      this.failureThreshold = failureThreshold;
      this.coolOffPeriodOfHalfOpen = coolOffPeriodOfHalfOpen;
      this.failureTimeWindow = failureTimeWindow;
      this.successThresholdForHalfOpen = successThresholdForHalfOpen;

    }

    public State getState(){
      return this.state;
    }

    public synchronized void recordFailure() {
      if(this.state ==  State.CLOSED) {

        failureTimestamps.removeIf(timestamp -> Duration.between(timestamp, now()).compareTo(failureTimeWindow) > 0);
        failureTimestamps.add(LocalDateTime.now());

        if(failureTimestamps.size() > failureThreshold) {
          moveToOpen();
        }
      }else if(this.state == State.HALF_OPEN) {
        moveToOpen();
      }
    }

    public void recordSuccess() {
      if(this.state == State.HALF_OPEN) {
        successCount++;
        if(successCount > successThresholdForHalfOpen) {
          moveToClose();
        }
      }
    }

    public void moveToOpen() {

    }

    public void moveToClose() {

    }

    public void moveToHalfOpen() {

    }

    public void isReadyForHalfOpen() {

    }

  }



}
