package com.zopa.fraudrisk.core;

import com.zopa.fraudrisk.infrastructure.exceptions.ProviderDataMismatchException;
import com.zopa.fraudrisk.infrastructure.exceptions.ProviderErrorException;

import java.util.Optional;

public interface FraudScoreProvider {

    Optional<FraudScore> getLatestScore(Person person) throws ProviderErrorException, ProviderDataMismatchException;
}
