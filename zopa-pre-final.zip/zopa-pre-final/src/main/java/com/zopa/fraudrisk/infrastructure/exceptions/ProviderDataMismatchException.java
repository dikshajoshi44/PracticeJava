package com.zopa.fraudrisk.infrastructure.exceptions;

public class ProviderDataMismatchException extends Exception {

    public ProviderDataMismatchException(String message) {
        super(message);
    }
}
