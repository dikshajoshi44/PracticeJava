package com.zopa.fraudrisk.infrastructure.exceptions;

public class ProviderErrorException extends RuntimeException {
    public ProviderErrorException(String message, Throwable cause) {
        super(message, cause);
    }
}
