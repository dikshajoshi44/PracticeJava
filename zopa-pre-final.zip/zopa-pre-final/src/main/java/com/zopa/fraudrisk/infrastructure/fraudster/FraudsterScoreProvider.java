package com.zopa.fraudrisk.infrastructure.fraudster;

import com.zopa.fraudrisk.core.FraudScore;
import com.zopa.fraudrisk.core.FraudScoreProvider;
import com.zopa.fraudrisk.core.Person;
import com.zopa.fraudrisk.infrastructure.exceptions.ProviderDataMismatchException;
import com.zopa.fraudrisk.infrastructure.exceptions.ProviderErrorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

public class FraudsterScoreProvider implements FraudScoreProvider {

  private final FraudsterClient fraudsterClient;
  private static final Logger logger = LoggerFactory.getLogger(FraudsterScoreProvider.class);

  public FraudsterScoreProvider(FraudsterClient fraudsterClient) {
    this.fraudsterClient = fraudsterClient;
  }

  @Override
  public Optional<FraudScore> getLatestScore(Person person) throws ProviderErrorException, ProviderDataMismatchException {
    FraudsterRequest fraudsterRequest = FraudsterRequest.fromPerson(person);

    try {
      FraudsterResponse fraudsterResponse = fraudsterClient.getScore(fraudsterRequest);
      if (fraudsterResponse == null) {
        return Optional.empty();
      }

      // Build a Person object from the response to validate data integrity
      var responsePerson = Person.builder()
        .email(fraudsterResponse.getEmailAddress())
        .firstName(fraudsterResponse.getFirstName())
        .lastName(fraudsterResponse.getSurname())
        .postCode(fraudsterResponse.getPostCode())
        .build();

      // Compare the request person with the response person
      if (!person.equals(responsePerson)) {
        var message = String.format("Data mismatch between request and Fraudster response. Request: %s, Response: %s", person, responsePerson);
        throw new ProviderDataMismatchException(message);
      }

      return Optional.of(FraudScore.builder()
        .person(responsePerson)
        .score(mapToScore(fraudsterResponse.getFraudRating()))
        .build());
    } catch (ProviderDataMismatchException e) {
      throw e;
    } catch (Exception ex) {
      logger.error(ex.getMessage(), ex);
      throw new ProviderErrorException(ex.getMessage(), ex.getCause());
    }
  }

  private int mapToScore(int fraudRating) {
    return fraudRating;
  }
}
