package com.zopa.fraudrisk.infrastructure.steerclear;

import com.zopa.fraudrisk.core.FraudScore;
import com.zopa.fraudrisk.core.FraudScoreProvider;
import com.zopa.fraudrisk.core.Person;
import com.zopa.fraudrisk.infrastructure.exceptions.ProviderErrorException;
import com.zopa.fraudrisk.infrastructure.steerclear.SteerClearResponse.RiskGroup;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Optional;

public class SteerClearScoreProvider implements FraudScoreProvider {

  private final SteerClearClient steerClearClient;
  private static final Logger logger = LoggerFactory.getLogger(SteerClearScoreProvider.class);

  public SteerClearScoreProvider(SteerClearClient steerClearClient) {
    this.steerClearClient = steerClearClient;
  }

  @Override
  public Optional<FraudScore> getLatestScore(Person person) throws ProviderErrorException {
    SteerClearRequest steerClearRequest = new SteerClearRequest(person.getEmail(), person.getFirstName(),
      person.getLastName(), person.getPostCode());

    try {
      SteerClearResponse steerClearResponse = steerClearClient.getScore(steerClearRequest);
      if (steerClearResponse == null) {
        return Optional.empty();
      }

      return Optional.of(mapToFraudScore(steerClearResponse));
    } catch(Exception ex) {
      logger.error("Failed to get score from SteerClearClient with error {}",
        ex.getMessage());
      throw new ProviderErrorException(ex.getMessage(), ex);
    }
  }

  private FraudScore mapToFraudScore(SteerClearResponse steerClearResponse) {
    return FraudScore.builder()
      .person(Person.builder()
        .email(steerClearResponse.getEmail())
        .firstName(steerClearResponse.getFirstName())
        .lastName(steerClearResponse.getLastName())
        .postCode(steerClearResponse.getPostCode())
        .build())
      .score(mapToScore(steerClearResponse.getRiskGroup()))
      .build();
  }

  private int mapToScore(RiskGroup riskGroup) {
    return switch(riskGroup){
      case A -> 0;
      case B -> 20;
      case C -> 40;
      case D -> 60;
      case E -> 80;
      case F -> 100;
    };
  }
}
