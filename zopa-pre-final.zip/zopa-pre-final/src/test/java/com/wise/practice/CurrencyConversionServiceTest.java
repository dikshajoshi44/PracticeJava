package com.wise.practice;

import com.wise.practice.exceptions.InvalidCurrencyException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;

class CurrencyConversionServiceTest {

    private CurrencyConversionService conversionService;

    @BeforeEach
    void setUp() {
        conversionService = new CurrencyConversionService();
    }

    @Test
    void shouldConvertSuccessfully() {
        BigDecimal amount = new BigDecimal("100");
        BigDecimal expected = new BigDecimal("85.0000");
        BigDecimal result = conversionService.convert("EUR", "GBP", amount);
        assertThat(result).isEqualTo(expected);
    }

    @Test
    void shouldReturnSameAmountForSameCurrency() {
        BigDecimal amount = new BigDecimal("100");
        BigDecimal result = conversionService.convert("EUR", "EUR", amount);
        assertThat(result).isEqualTo(amount);
    }

    @Test
    void shouldThrowExceptionForNullFromCurrency() {
        assertThrows(IllegalArgumentException.class, () -> {
            conversionService.convert(null, "GBP", new BigDecimal("100"));
        });
    }

    @Test
    void shouldThrowExceptionForNullToCurrency() {
        assertThrows(IllegalArgumentException.class, () -> {
            conversionService.convert("EUR", null, new BigDecimal("100"));
        });
    }

    @Test
    void shouldThrowExceptionForNullAmount() {
        assertThrows(IllegalArgumentException.class, () -> {
            conversionService.convert("EUR", "GBP", null);
        });
    }

    @Test
    void shouldThrowExceptionForNegativeAmount() {
        assertThrows(IllegalArgumentException.class, () -> {
            conversionService.convert("EUR", "GBP", new BigDecimal("-100"));
        });
    }

    @Test
    void shouldThrowExceptionForMissingRate() {
        assertThrows(InvalidCurrencyException.class, () -> {
            conversionService.convert("USD", "JPY", new BigDecimal("100"));
        });
    }

    @Test
    void shouldUpdateRateAndConvert() {
        BigDecimal newRate = new BigDecimal("0.90");
        conversionService.updateExchangeRate("EUR", "GBP", newRate);
        BigDecimal amount = new BigDecimal("100");
        BigDecimal expected = new BigDecimal("90.0000");
        BigDecimal result = conversionService.convert("EUR", "GBP", amount);
        assertThat(result).isEqualTo(expected);
    }

    @Test
    void shouldBeThreadSafe() throws InterruptedException {
        int numberOfThreads = 100;
        ExecutorService service = Executors.newFixedThreadPool(numberOfThreads);
        CountDownLatch latch = new CountDownLatch(numberOfThreads);

        // Initial rate
        conversionService.updateExchangeRate("EUR", "GBP", new BigDecimal("0.85"));

        for (int i = 0; i < numberOfThreads; i++) {
            final int threadNum = i;
            service.submit(() -> {
                try {
                    // Some threads will read, others will write
                    if (threadNum % 2 == 0) {
                        BigDecimal amount = new BigDecimal("100");
                        conversionService.convert("EUR", "GBP", amount);
                    } else {
                        // Update with a slightly different rate
                        BigDecimal newRate = new BigDecimal("0.85").add(new BigDecimal(threadNum).divide(new BigDecimal("1000")));
                        conversionService.updateExchangeRate("EUR", "GBP", newRate);
                    }
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await(5, TimeUnit.SECONDS); // Wait for all threads to complete
        service.shutdown();

        // After all the concurrent operations, the final conversion should use the last updated rate.
        // This is not a deterministic check of the final value, but it ensures that no exceptions were thrown
        // and the service remains in a consistent state.
        BigDecimal finalAmount = new BigDecimal("100");
        BigDecimal finalResult = conversionService.convert("EUR", "GBP", finalAmount);

        // The final result should be one of the possible outcomes.
        assertThat(finalResult).isNotNull();
    }
}
