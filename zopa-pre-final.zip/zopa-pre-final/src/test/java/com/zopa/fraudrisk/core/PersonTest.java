package com.zopa.fraudrisk.core;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.NullAndEmptySource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class PersonTest {

  private static final String VALID_EMAIL = "test@example.com";
  private static final String VALID_FIRST_NAME = "John";
  private static final String VALID_LAST_NAME = "Doe";
  private static final String VALID_POSTCODE = "SW1A 0AA";

  @ParameterizedTest
  @NullAndEmptySource
  @DisplayName("Should throw exception for null or empty fields")
  void shouldThrowExceptionForNullOrEmptyFields(String input) {
    // Test null/empty email
    assertThatThrownBy(() -> Person.builder().email(input).firstName(VALID_FIRST_NAME).lastName(VALID_LAST_NAME).postCode(VALID_POSTCODE).build())
      .isInstanceOf(IllegalArgumentException.class)
      .hasMessage("Email cannot be null or empty.");

    // Test null/empty first name
    assertThatThrownBy(() -> Person.builder().email(VALID_EMAIL).firstName(input).lastName(VALID_LAST_NAME).postCode(VALID_POSTCODE).build())
      .isInstanceOf(IllegalArgumentException.class)
      .hasMessage("First name cannot be null or empty.");

    // Test null/empty last name
    assertThatThrownBy(() -> Person.builder().email(VALID_EMAIL).firstName(VALID_FIRST_NAME).lastName(input).postCode(VALID_POSTCODE).build())
      .isInstanceOf(IllegalArgumentException.class)
      .hasMessage("Last name cannot be null or empty.");

    // Test null/empty post code
    assertThatThrownBy(() -> Person.builder().email(VALID_EMAIL).firstName(VALID_FIRST_NAME).lastName(VALID_LAST_NAME).postCode(input).build())
      .isInstanceOf(IllegalArgumentException.class)
      .hasMessage("Post code cannot be null or empty.");
  }

  @ParameterizedTest
  @ValueSource(strings = {"plainaddress", "@example.com"})
  @DisplayName("Should throw exception for invalid email format")
  void shouldThrowExceptionForInvalidEmailFormat(String invalidEmail) {
    assertThatThrownBy(() -> Person.builder().email(invalidEmail).firstName(VALID_FIRST_NAME).lastName(VALID_LAST_NAME).postCode(VALID_POSTCODE).build())
      .isInstanceOf(IllegalArgumentException.class)
      .hasMessage("Invalid email format.");
  }

  @Test
  @DisplayName("Should trim whitespace from all fields")
  void shouldTrimWhitespaceFromFields() {
    Person person = Person.builder()
      .email("  test@example.com  ")
      .firstName("  John  ")
      .lastName("  Doe  ")
      .postCode("  SW1A 0AA  ")
      .build();

    assertThat(person.getEmail()).isEqualTo(VALID_EMAIL);
    assertThat(person.getFirstName()).isEqualTo(VALID_FIRST_NAME);
    assertThat(person.getLastName()).isEqualTo(VALID_LAST_NAME);
    assertThat(person.getPostCode()).isEqualTo(VALID_POSTCODE);
  }

  @Test
  @DisplayName("Should build a valid Person")
  public void shouldBuildValidPerson() {
    Person person = Person.builder()
      .email(VALID_EMAIL)
      .firstName(VALID_FIRST_NAME)
      .lastName(VALID_LAST_NAME)
      .postCode(VALID_POSTCODE)
      .build();

    assertThat(person.getEmail()).isEqualTo(VALID_EMAIL);
    assertThat(person.getFirstName()).isEqualTo(VALID_FIRST_NAME);
    assertThat(person.getLastName()).isEqualTo(VALID_LAST_NAME);
    assertThat(person.getPostCode()).isEqualTo(VALID_POSTCODE);
  }
}
