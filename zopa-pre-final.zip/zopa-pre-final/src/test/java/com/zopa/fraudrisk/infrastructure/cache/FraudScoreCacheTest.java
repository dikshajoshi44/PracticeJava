package com.zopa.fraudrisk.infrastructure.cache;

import com.zopa.fraudrisk.common.TestPersonFactory;
import com.zopa.fraudrisk.core.FraudScore;
import com.zopa.fraudrisk.core.Person;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Optional;

class FraudScoreCacheTest {

  @Test
  public void shouldReturnSavedScore() {
    FraudScoreCache fraudScoreCache = FraudScoreCache.getInstance();
    Person person = TestPersonFactory.getTestPerson();
    FraudScore fraudScore = FraudScore.builder()
      .person(person)
      .score(73).build();

    fraudScoreCache.saveScore(fraudScore);
    Optional<FraudScore> optionalScore = fraudScoreCache.getScore(person);

    Assertions.assertThat(optionalScore.isPresent()).isTrue();
    Assertions.assertThat(optionalScore.get().getScore()).isEqualTo(73);
  }

  @Test
  public void shouldReturnDifferentScoreForSameEmailButOtherParamsDifferent() {
    FraudScoreCache fraudScoreCache = FraudScoreCache.getInstance();
    Person person1 = Person.builder()
      .email("abc@gmail.com")
      .firstName("Diksha")
      .lastName("Joshi")
      .postCode("E1 6AN")
      .build();
    Person person2 = Person.builder()
      .email("abc@gmail.com")
      .firstName("Anugya")
      .lastName("Joshi")
      .postCode("E1 6AN")
      .build();
    FraudScore fraudScore1 = FraudScore.builder()
      .person(person1)
      .score(73).build();
    FraudScore fraudScore2 = FraudScore.builder()
      .person(person2)
      .score(80).build();

    fraudScoreCache.saveScore(fraudScore1);

    Optional<FraudScore> optionalScore = fraudScoreCache.getScore(person1);
    Assertions.assertThat(optionalScore.isPresent()).isTrue();
    Assertions.assertThat(optionalScore.get().getScore()).isEqualTo(73);

    fraudScoreCache.saveScore(fraudScore2);
    Optional<FraudScore> optionalScore2 = fraudScoreCache.getScore(person2);
    Assertions.assertThat(optionalScore2.isPresent()).isTrue();
    Assertions.assertThat(optionalScore2.get().getScore()).isEqualTo(80);
  }

}
