package com.zopa.fraudrisk.infrastructure.steerclear;

import com.zopa.fraudrisk.common.TestPersonFactory;
import com.zopa.fraudrisk.core.FraudScore;
import com.zopa.fraudrisk.core.Person;
import com.zopa.fraudrisk.infrastructure.exceptions.ProviderErrorException;
import com.zopa.fraudrisk.infrastructure.steerclear.SteerClearResponse.RiskGroup;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class SteerClearScoreProviderTest {

  @ParameterizedTest
  @CsvSource({
    "A,0",
    "B,20",
    "C,40",
    "D,60",
    "E,80",
    "F,100"
  })
  @DisplayName("Should fetch risk group for a person")
  void shouldFetchLatestScore(RiskGroup riskGroup, int score) {
    SteerClearClient steerClearClientMock = mock(SteerClearClient.class);
    SteerClearScoreProvider steerClearScoreProvider = new SteerClearScoreProvider(steerClearClientMock);
    Person person = TestPersonFactory.getTestPerson();
    SteerClearResponse steerClearResponse = new SteerClearResponse(person.getEmail(), person.getFirstName(),
      person.getLastName(), person.getPostCode(), riskGroup);
    when(steerClearClientMock.getScore(any(SteerClearRequest.class))).thenReturn(steerClearResponse);

    Optional<FraudScore> latestScore = steerClearScoreProvider.getLatestScore(person);

    assertThat(latestScore.isPresent()).isTrue();
    FraudScore fraudScore = latestScore.get();
    assertThat(fraudScore.getPerson()).isEqualTo(person);
    assertThat(fraudScore.getScore()).isEqualTo(score);
  }

  @Test
  @DisplayName("Should handle client exception gracefully")
  void shouldHandleExceptionGracefully() {
    SteerClearClient steerClearClientMock = mock(SteerClearClient.class);
    SteerClearScoreProvider steerClearScoreProvider = new SteerClearScoreProvider(steerClearClientMock);
    Person person = TestPersonFactory.getTestPerson();
    when(steerClearClientMock.getScore(any(SteerClearRequest.class))).thenThrow(new RuntimeException("Provider error"));
    assertThatThrownBy(() ->
      steerClearScoreProvider.getLatestScore(person))
      .isInstanceOf(ProviderErrorException.class)
      .hasMessage("Provider error");
  }
}
